package cp213;


public class A06{

	public static void main(String[] args) {
				
		final A06Panel threadView = new A06OverallView();
		final A06Frames grid = new A06Frames("Thread View");
		grid.setContentPane(threadView);
		grid.setSize(1400,350);
		grid.setDefaultCloseOperation(A06Frames.EXIT_ON_CLOSE);
		grid.setVisible(true);
		
	}
}
