package cp213;

import java.awt.BorderLayout;

import java.awt.Color;

import javax.swing.Timer;

public class A06OverallView extends A06Panel {
	
	private final A06Buttons addThread = new A06Buttons("Add a Thread");
	private final A06Buttons deleteThread = new A06Buttons("Delete a Thread");
	
	public static A06Labels threadCount = new A06Labels("Number of Threads: " + A06Listeners.totalThreads);
	public static A06Labels warning = new A06Labels("");
	
	public static A06ThreadView tView1 = null;
	public static A06ThreadView tView2 = null;
	public static A06ThreadView tView3 = null;
	public static A06ThreadView tView4 = null;
	public static A06ThreadView tView5 = null;
	
	public A06OverallView() {
	
	tView1 = new A06ThreadView();
	tView2 = new A06ThreadView();
	tView3 = new A06ThreadView();
	tView4 = new A06ThreadView();
	tView5 = new A06ThreadView();
	this.layoutView();
	this.registerListeners();
	
	}
	
	private void layoutView() {
		this.setLayout(null);
		
		addThread.setBounds(30, 80, 200, 50);
		this.add(addThread);
		deleteThread.setBounds(30, 150, 200, 50);
		this.add(deleteThread);
		
		threadCount.setBounds(34, 20, 200,50);
		this.add(threadCount);
		
		warning.setBounds(700, 250, 250, 70);
		this.add(warning);
		
		tView1.setBounds(300, 50, 150, 200);
		tView1.setBackground(Color.RED);
		tView1.setVisible(false);
		this.add(tView1);	
		
		tView2.setBounds(500, 50, 150, 200);
		tView2.setBackground(Color.RED);
		tView2.setVisible(false);
		this.add(tView2);	
		
		tView3.setBounds(700, 50, 150, 200);
		tView3.setBackground(Color.RED);
		tView3.setVisible(false);
		this.add(tView3);	
		
		tView4.setBounds(900, 50, 150, 200);
		tView4.setBackground(Color.RED);
		tView4.setVisible(false);
		this.add(tView4);	
		
		tView5.setBounds(1100, 50, 150, 200);
		tView5.setBackground(Color.RED);
		tView5.setVisible(false);
		this.add(tView5);	
		
	}
	
	private void registerListeners() {
		
		addThread.addActionListener(new A06Listeners("add"));
		deleteThread.addActionListener(new A06Listeners("delete"));
	}
	
	
}
