package cp213;

import java.awt.Color;
import java.awt.Font;


public class A06ThreadView extends A06Panel{
	
	private final A06Labels title = new A06Labels("Thread #");
	
	private final A06Labels status = new A06Labels("Status: ");
	
	private final A06Labels RunTime = new A06Labels("RunTime: ");
	
	private final A06Labels SleepTime = new A06Labels("SleepTime: ");
	
	
	public A06ThreadView() {
		this.layoutView();
	
	}
	
	
	
	private void layoutView() {
		this.setLayout(null);
		
		title.setBounds(40, 10, 100, 20);
		title.setFont(new Font("Calibri", Font.BOLD, 16));
		this.add(title);
		status.setBounds(10, 100, 200, 20);
		status.setFont(new Font("Calibri", Font.BOLD, 16));
		this.add(status);
		RunTime.setBounds(10, 140, 100, 20);
		RunTime.setFont(new Font("Calibri", Font.BOLD, 16));
		this.add(RunTime);
		SleepTime.setBounds(10, 170, 150, 20);
		SleepTime.setFont(new Font("Calibri", Font.BOLD, 16));
		this.add(SleepTime);			
		
	}
	
	public A06Labels getTitle() {
		return this.title;
	}
	
	public void setTitle(String text) {
		this.title.setText(text);
	}
	
	public A06Labels getStatus() {
		return this.status;
	}
	
	public void setStatus(String text) {
		this.status.setText(text);
	}
	
	public A06Labels getRunTime() {
		return this.RunTime;
	}
	
	public void setRunTime(String text) {
		this.RunTime.setText(text);
	}
	
	public A06Labels getSleepTime() {
		return this.SleepTime;
	}
	
	public void setSleepTime(String text) {
		this.SleepTime.setText(text);
	}

}
