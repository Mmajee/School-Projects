package cp213;

import javax.swing.JPanel;

public class A06Panel extends JPanel{

}
