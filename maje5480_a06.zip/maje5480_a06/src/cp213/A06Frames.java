package cp213;

import javax.swing.JFrame;

public class A06Frames extends JFrame{

	public A06Frames(String string) {
		// TODO Auto-generated constructor stub
		this.setTitle(string);
	}
	
	
}
