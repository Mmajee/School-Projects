package cp213;

import java.awt.Color;

import java.util.concurrent.ThreadLocalRandom;

import javax.swing.Timer;


public class A06Threads implements Runnable {

	private int randomInt = ThreadLocalRandom.current().nextInt(100, 200);
	
	private int randomInt2 = ThreadLocalRandom.current().nextInt(100, 200);
	
	public static int exit;
	
	private int threadID;
	
	private Timer timer1 = new Timer(randomInt, new A06Listeners("timer1"));
	
	private Timer timer2 = new Timer(randomInt, new A06Listeners("timer2"));
	
	private Timer timer3 = new Timer(randomInt, new A06Listeners("timer3"));
	
	private Timer timer4 = new Timer(randomInt, new A06Listeners("timer4"));
	
	private Timer timer5 = new Timer(randomInt, new A06Listeners("timer5"));
	
	public A06Threads(int num) {
		threadID = num;
	}
	
	public int getNum() {
		return this.threadID;
	}
	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub

		
		if (this.threadID == 1 && exit != 1) {
			
			A06OverallView.tView1.setBackground(Color.RED);
			
			A06OverallView.tView1.setStatus("Status: Sleeping" );
			
			try {
				Thread.sleep(randomInt2);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			timer1.start();
			
			A06OverallView.tView1.setSleepTime("SleepTime: " + randomInt2);
			
			A06OverallView.tView1.setStatus("Status: Running" );
			
			
			A06OverallView.tView1.setBackground(Color.GREEN);

		}
		
		if (this.threadID == 2 && exit != 2) {
			A06OverallView.tView2.setBackground(Color.RED);
			
			A06OverallView.tView2.setStatus("Status: Sleeping" );
			
			try {
				Thread.sleep(randomInt2);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			timer2.start();
			
			A06OverallView.tView2.setSleepTime("SleepTime: " + randomInt2);
			
			A06OverallView.tView2.setStatus("Status: Running" );
			
			A06OverallView.tView2.setBackground(Color.GREEN);
			
		}
		
		if (this.threadID == 3 && exit != 3) {
			A06OverallView.tView3.setBackground(Color.RED);
			
			A06OverallView.tView3.setStatus("Status: Sleeping" );
			
			try {
				Thread.sleep(randomInt2);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			timer3.start();
			
			A06OverallView.tView3.setSleepTime("SleepTime: " + randomInt2);
			
			A06OverallView.tView3.setStatus("Status: Running" );
			
			A06OverallView.tView3.setBackground(Color.GREEN);
			
		}
		
		if (this.threadID == 4 && exit != 4) {
			A06OverallView.tView4.setBackground(Color.RED);
			
			A06OverallView.tView4.setStatus("Status: Sleeping" );
			
			try {
				Thread.sleep(randomInt2);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			timer4.start();
			
			A06OverallView.tView4.setSleepTime("SleepTime: " + randomInt2);
			
			A06OverallView.tView4.setStatus("Status: Running" );
			
			A06OverallView.tView4.setBackground(Color.GREEN);
			
		}
		
		if (this.threadID == 5 && exit != 5) {
			A06OverallView.tView5.setBackground(Color.RED);
			
			A06OverallView.tView5.setStatus("Status: Sleeping" );
			
			try {
				Thread.sleep(randomInt2);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			timer5.start();
			
			A06OverallView.tView5.setSleepTime("SleepTime: " + randomInt2);
			
			A06OverallView.tView5.setStatus("Status: Running" );
			
			A06OverallView.tView5.setBackground(Color.GREEN);
			
		}
		
	}
	
	
	public int getID() {
		return this.threadID;
	}
    
    public int getRandom() {
    	return this.randomInt;
    }
    
    public Timer getTimer1() {
    	return this.timer1;
    }
    
    public Timer getTimer2() {
    	return this.timer2;
    }
    
    public Timer getTimer3() {
    	return this.timer3;
    }
    
    public Timer getTimer4() {
    	return this.timer4;
    }
    
    public Timer getTimer5() {
    	return this.timer5;
    }

}
