package cp213;

import javax.swing.JButton;

public class A06Buttons extends JButton {
	
	public A06Buttons(String text) {
		this.setText(text);
	}
}
