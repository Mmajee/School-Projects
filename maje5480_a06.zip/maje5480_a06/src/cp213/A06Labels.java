package cp213;

import javax.swing.JLabel;
import java.awt.Font;

public class A06Labels extends JLabel{

	public A06Labels(String text) {
		this.setText(text);
	}

}
