package cp213;

import java.awt.Color;
import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;


public class A06Listeners implements ActionListener{
	
	private String componentID;
	
	public static int totalThreads = 0;
	
	private final int MAX_THREADS = 5;
	
	public static A06Threads obj1 = new A06Threads(1);
	private static A06Threads obj2;
	private static A06Threads obj3;
	private static A06Threads obj4;
	private static A06Threads obj5;

	private static Thread th1;
	private static Thread th2;
	private static Thread th3;
	private static Thread th4;
	private static Thread th5;
	
	private static A06Threads oldest = obj1;

	public A06Listeners(String arg) {
		componentID = arg;
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		
		if (componentID.equals("add")) {
			
			if ((totalThreads + 1) > MAX_THREADS) {
				A06OverallView.warning.setText("You have reached the maximum threads!");
			}
			else {
				
				A06Threads.exit = 0;
				
				A06OverallView.warning.setText("");
				
				if (!A06OverallView.tView1.isVisible()) {
					
					obj1 = new A06Threads(1);
							
					A06OverallView.tView1.setTitle("Thread #1");
					
					A06OverallView.tView1.setBackground(Color.GREEN);
					
					A06OverallView.tView1.setVisible(true);
					
					obj1.getTimer1().start();
					
					
				}
				else if (!A06OverallView.tView2.isVisible()) {
					
					obj2 = new A06Threads(2);
					
					A06OverallView.tView2.setTitle("Thread #2");
					
					A06OverallView.tView2.setBackground(Color.GREEN);
					
					A06OverallView.tView2.setVisible(true);
				
					obj2.getTimer2().start();
				}
				else if (!A06OverallView.tView3.isVisible()) {
					
					obj3 = new A06Threads(3);
					
					A06OverallView.tView3.setTitle("Thread #3");
					
					A06OverallView.tView3.setBackground(Color.GREEN);
					
					A06OverallView.tView3.setVisible(true);
				
					obj3.getTimer3().start();
				}
				else if (!A06OverallView.tView4.isVisible()) {
					
					obj4 = new A06Threads(4);
					
					A06OverallView.tView4.setTitle("Thread #4");
					
					A06OverallView.tView4.setBackground(Color.GREEN);
					
					A06OverallView.tView4.setVisible(true);
				
					obj4.getTimer4().start();
				}
				else{
					
					obj5 = new A06Threads(5);
					
					A06OverallView.tView5.setTitle("Thread #5");
					
					A06OverallView.tView5.setBackground(Color.GREEN);
					
					A06OverallView.tView5.setVisible(true);
				
					obj5.getTimer5().start();
				}
			
				
				totalThreads += 1;
				
				A06OverallView.threadCount.setText("Number of Threads: " + totalThreads);	
			}
				
		}
		
		if (componentID.equals("delete")) {
			
			if (totalThreads == 0) {
				A06OverallView.warning.setText("No threads to delete!");
			}
			else {
				A06OverallView.warning.setText("");
				
				A06Threads.exit = oldest.getID();
				
				totalThreads -= 1;
				
				A06OverallView.threadCount.setText("Number of Threads: " + totalThreads);
				
				if (oldest.getID() == 1) {
					A06OverallView.tView1.setVisible(false);
					
					if (A06OverallView.tView2.isVisible()) {
						oldest = obj2;
					}
					else if(A06OverallView.tView5.isVisible()){
						oldest = obj5;
					}
					else {
						oldest = obj1;
					}
				}
				else if (oldest.getID() == 2) {
					A06OverallView.tView2.setVisible(false);
					
					if (A06OverallView.tView3.isVisible()) {
						oldest = obj3;
					}
					else if(A06OverallView.tView1.isVisible()){
						oldest = obj1;
					}
					else {
						oldest = obj2;
					}
				}
				else if (oldest.getID() == 3) {
					A06OverallView.tView3.setVisible(false);
					
					if (A06OverallView.tView4.isVisible()) {
						oldest = obj4;
					}
					else if(A06OverallView.tView2.isVisible()){
						oldest = obj2;
					}
					else {
						oldest = obj3;
					}
				}
				else if (oldest.getID() == 4) {
					A06OverallView.tView4.setVisible(false);
					
					if (A06OverallView.tView5.isVisible()) {
						oldest = obj5;
					}
					else if(A06OverallView.tView3.isVisible()){
						oldest = obj3;
					}
					else {
						oldest = obj4;
					}
				}
				else if (oldest.getID() == 5) {
					A06OverallView.tView5.setVisible(false);
					
					if (A06OverallView.tView1.isVisible()) {
						oldest = obj1;
					}
					else if(A06OverallView.tView4.isVisible()){
						oldest = obj4;
					}
					else {
						oldest = obj5;
					}
				}
				
				
			}
			
		}
		
		if (componentID.equals("timer1")) {
			if (A06OverallView.tView1.isVisible()) {
				A06OverallView.tView1.setBackground(Color.RED);
				A06OverallView.tView1.setRunTime("RunTime: " + obj1.getRandom());
				
				th1 = new Thread(obj1);
				th1.start();
				
				obj1.getTimer1().stop();
				
			}
			
		}
		
		if (componentID.equals("timer2")) {
			if(A06OverallView.tView2.isVisible()) {
				A06OverallView.tView2.setBackground(Color.RED);
				A06OverallView.tView2.setRunTime("RunTime: " + obj2.getRandom());
				
				th2 = new Thread(obj2);
				th2.start();
				
				obj2.getTimer2().stop();
				
			}
			
		}
		
		if (componentID.equals("timer3")) {
			
			if(A06OverallView.tView3.isVisible()) {
				A06OverallView.tView3.setBackground(Color.GREEN);
				A06OverallView.tView3.setRunTime("RunTime: " + obj3.getRandom());
				
				th3 = new Thread(obj3);
				th3.start();
				
				obj3.getTimer3().stop();
			}
			
		}
		
		if (componentID.equals("timer4")) {
			
			if(A06OverallView.tView4.isVisible()) {
				A06OverallView.tView4.setBackground(Color.RED);
				A06OverallView.tView4.setRunTime("RunTime: " + obj4.getRandom());
				
				th4 = new Thread(obj4);
				th4.start();
				
				obj4.getTimer4().stop();
			}
			
		}
		
		if (componentID.equals("timer5")) {
			
			if(A06OverallView.tView5.isVisible()) {
				A06OverallView.tView5.setBackground(Color.RED);
				A06OverallView.tView5.setRunTime("RunTime: " + obj5.getRandom());
				
				th5 = new Thread(obj5);
				th5.start();
				
				obj5.getTimer5().stop();
			}
			
		}
		
		
	}



}
